﻿AUTHOR: Temag

buymeacoffee.com/temag33

BlueBird 757 — Weather Radar Mod 3.3 (MSFS 2024)


Compatibility: BlueBird 757 v1.1

Installation:

Extract the zz-bbs757-wxr folder into your MSFS Community folder.

Enjoy! :)

